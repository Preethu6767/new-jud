## About [/about]
## About [GET]
Returns general information.

+ Response 200 (application/json)
    + Body
        {
            "version": "1.5.0",
            "homepage": "https://judge0.com",
            "source_code": "https://github.com/judge0/judge0",
            "maintainer": "Herman Zvonimir Došilović <hermanz.dosilovic@gmail.com>"
        }