# Group Statistics
## Statistics [/statistics]
### Statistics [GET]

Get some statistics from current instance. Result is cached for 10 minutes.

+ Parameters
    + invalidate_cache (optional, boolean, `false`) ... Set to `true` if you want to invalidate current cache and fetch new statistics.
